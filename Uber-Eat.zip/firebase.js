import firebase from "firebase";

const firebaseConfig = {
    apiKey: "AIzaSyAsnJ--d5wTj67cobGPSxakHFzm24z8Rzw",
    authDomain: "rn-uber-eat-e430c.firebaseapp.com",
    projectId: "rn-uber-eat-e430c",
    storageBucket: "rn-uber-eat-e430c.appspot.com",
    messagingSenderId: "925424979049",
    appId: "1:925424979049:web:b68ac0ad92e26e8166a6f8"
  };
  
  !firebase.apps.length ? firebase.initializeApp(firebaseConfig) : firebase.app();

  export default firebase;